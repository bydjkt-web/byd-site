# Upload ZIP ke repository

1. Buka folder `upload` ini di GitHub, klik **Add file > Upload files**.
2. Pilih file `.zip` (ekstensi harus huruf kecil `.zip`, ukuran maksimal 25 MB lewat browser), lalu **Commit changes**.
3. Buka tab **Actions**: workflow "Extract ZIP upload" berjalan otomatis (sekitar 20 detik). Centang hijau berarti selesai.
4. Isi zip sudah muncul di root repository, file zip-nya terhapus otomatis, dan GitHub Pages memperbarui situs dalam 1 sampai 3 menit.

Catatan:
- Isi zip boleh langsung file website atau dibungkus satu folder; pembungkus otomatis dibuang.
- File yang sama akan ditimpa. File yang tercantum di `.extract-ignore` (mis. `js/firebase-config.js`) tidak akan ditimpa.
- Folder `.github` tidak pernah ditimpa oleh zip.
- Jika gagal dengan pesan "permission denied": Settings > Actions > General > Workflow permissions > pilih **Read and write permissions** > Save, lalu jalankan ulang dari tab Actions.
